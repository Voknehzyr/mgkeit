﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MenuItem_Click_Blue(object sender, RoutedEventArgs e)
        {
            this.Background = Brushes.Blue;
        }

        private void MenuItem_Click_RedText(object sender, RoutedEventArgs e)
        {
            this.label1.Foreground = Brushes.Red;
        }

        private void MenuItem_MouseEnter_Exit(object sender, MouseEventArgs e)
        {
            this.statusbar.Text = "Выйти из программы";
        }

        private void MenuItem_MouseEnter_Blue(object sender, MouseEventArgs e)
        {
            this.statusbar.Text = "Красит фон приложения в синий цвет";
        }

        private void MenuItem_MouseEnter_Red(object sender, MouseEventArgs e)
        {
            this.statusbar.Text = "Красит текст в приложении в красный цвет";
        }

        private void MenuItem_MouseEnter_About(object sender, MouseEventArgs e)
        {
            this.statusbar.Text = "Показывает создателя программы";
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Сделал Игорь Рыженков");
        }
    }
}
