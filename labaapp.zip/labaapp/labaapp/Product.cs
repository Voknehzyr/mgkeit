﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace labaapp
{
    public partial class Product : Form
    {
        public Product()
        {
            InitializeComponent();
        }

        private void Manufacturers_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "st05DataSet.Product". При необходимости она может быть перемещена или удалена.
            this.productTableAdapter.Fill(this.st05DataSet.Product);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "st05DataSet.makerProd". При необходимости она может быть перемещена или удалена.
            try
            {
                this.makerProdTableAdapter.Fill(this.st05DataSet.makerProd);
            } catch (Exception ex)
            {
                Console.WriteLine(this.st05DataSet.HasErrors);
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form frm = new Products();
            frm.Show();
        }
    }
}
