﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace labaapp
{
    public partial class Products : Form
    {
        public Products()
        {
            InitializeComponent();
        }

        private void productBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.st05DataSet);

        }

        private void Products_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "st05DataSet.Product". При необходимости она может быть перемещена или удалена.
            this.productTableAdapter.Fill(this.st05DataSet.Product);

        }

        private void productDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            button1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataGridViewColumn COL = new System.Windows.Forms.DataGridViewColumn(); 

            //блок switch, присваивающий в  
            //переменную Col имя выбранного столбца таблицы в зависимости от номера   //выбранного пункта списка (ListBox1.SelectedIndex). Если выбран первый пункт   //списка, то в переменную Col записывается столбец  
            //DataGridViewTextBoxColumn2, если второй, то – DataGridViewTextBoxColumn3   //и так далее. Хотелось бы отметить тот факт, что нумерация пунктов списка   //начинается с нуля, а нумерация столбцов с единицы. Первый столбец  «Наименование»  
            //носит имя DataGridViewTextBoxColumn2, так как имя  
            //DataGridViewTextBoxColumn1 имеет столбец заголовков строк;    
            switch (listBox1.SelectedIndex)
            {
                case 0:
                    COL = dataGridViewTextBoxColumn1;
                    break;
                case 1:
                    COL = dataGridViewTextBoxColumn2;
                    break;
                case 2:
                    COL = dataGridViewTextBoxColumn3;
                    break;
            }
            //Блок If выполняет следующую операцию: если включён 
            //переключатель «Сортировка по возрастанию» (RadioButton1), то отсортировать   //таблицу по полю заданному в переменной Col по возрастанию   //(productDataGridView.Sort (Col, System.ComponentModel.ListSortDirection.   //Ascending)), иначе по убыванию (productDataGridView.Sort (Col, System.   //ComponentModel.ListSortDirection. Descending)). 
            if (radioButton1.Checked)
                productDataGridView.Sort(COL,
               System.ComponentModel.ListSortDirection.Ascending);
            else
                productDataGridView.Sort(COL,
               System.ComponentModel.ListSortDirection.Descending);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            productBindingSource.Filter = "model='" + comboBox1.Text + "'";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            productBindingSource.Filter = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //перебирает все ячейки таблицы и  
            //устанавливает в них белый цвет фона и чёрный цвет текста, то есть,   //отменяет результаты предыдущего поиска 
            for (int i = 0; i < productDataGridView.ColumnCount - 1; i++)
            {
                for (int j = 0; j < productDataGridView.RowCount - 1; j++)
                {
                    productDataGridView[i, j].Style.BackColor = Color.White; productDataGridView[i, j].Style.ForeColor = Color.Black;
                }
            }
            //перебирает все ячейки таблицы и если они  
            //содержат текст, введённый в поле ввода (TextBox1), то устанавливает в них   //голубой цвет фона и синий цвет текста, чем выделяет искомые ячейки.  for (int i = 0; i < productDataGridView.ColumnCount - 1; i++)  { 
            for (int i = 0; i < productDataGridView.ColumnCount - 1; i++)
            {
                for (int j = 0; j < productDataGridView.RowCount - 1; j++)
                {
                    if (productDataGridView[i, j].Value.ToString().IndexOf(textBox1.Text) != -1)
                    {
                        productDataGridView[i, j].Style.BackColor = Color.AliceBlue; productDataGridView[i, j].Style.ForeColor = Color.Blue;

                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
